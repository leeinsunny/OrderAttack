package com.example.orderattack.game.kiosk

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.orderattack.R

class KioskBonusActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kiosk_bonus)
    }
}