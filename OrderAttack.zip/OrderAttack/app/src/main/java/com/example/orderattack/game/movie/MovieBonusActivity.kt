package com.example.orderattack.game.movie

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.orderattack.R

class MovieBonusActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_bonus)
    }
}