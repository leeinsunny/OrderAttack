package com.example.orderattack.game.movie

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.orderattack.R

class MovieStep1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_step1)
    }
}