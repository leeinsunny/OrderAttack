package com.example.orderattack.Healingtown

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.orderattack.R

class HealingMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_healing_main)
    }
}