package com.example.orderattack.game.bus

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.orderattack.R

class BusStep3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bus_step3)
    }
}